# Silent Library Website — Technical & User Documentation

**Project:** Silent Library Website (Milestone 1)
**Student:** Iskandar Bin Hussin
**Module:** User Interface Design (Bundled) (SF)
**Date:** 28 August 2026

---

## 1. Project Overview

Silent Library is a modern, responsive website designed for a public library. It provides users with easy access to the library's book catalog, events, and information. The website features a clean, professional design with warm, library-appropriate colors and intuitive navigation.

### Pages Included
1. **index.html** — Landing Page with hero, features, featured books, stats, events
2. **books.html** — Books List with search, category filter, availability filter
3. **book-details.html** — Book Details page with synopsis, metadata, availability
4. **events.html** — Events & Promotions with featured event, event grid, promotions
5. **sitemap.html** — Complete sitemap with site structure overview
6. **contact.html** — Contact page with cards, form, FAQ accordion
7. **privacy.html** — Privacy Policy document

---

## 2. Technology Stack

| Component | Technology | Version |
|---|---|---|
| Frontend Framework | Bootstrap | 5.3.3 |
| Icons | Bootstrap Icons | 1.11.3 |
| Fonts | Google Fonts (Comfortaa + Source Sans 3) | Latest |
| Styling | CSS3 (Custom) | — |
| Scripting | Vanilla JavaScript (ES6+) | — |
| Markup | HTML5 Semantic | — |

---

## 3. File Structure

```
website/
├── index.html              # Landing Page
├── books.html              # Books List Page
├── book-details.html       # Book Details Page
├── events.html             # Events & Promotions Page
├── sitemap.html            # Sitemap Page
├── contact.html            # Contact Page
├── privacy.html            # Privacy Policy Page
├── css/
│   └── style.css           # Custom stylesheet
├── js/
│   └── script.js           # JavaScript functionality
└── images/                 # Image assets folder
```

---

## 4. JavaScript Interactive Components

### 4.1 Book Search & Filter System
- **Real-time search** by book title or author
- **Category filter** dropdown (Fiction, Non-Fiction, Sci-Fi, Mystery, Biography, Self-Help, Finance)
- **Availability filter** (Available / On Loan)
- Results count display updates dynamically
- "No results" message when filters match nothing

### 4.2 Mobile Navigation Toggle
- Bootstrap responsive navbar with hamburger menu
- Collapses automatically on mobile screens
- Smooth transition animations

### 4.3 Event Registration Modal
- Bootstrap modal popup triggered by "Register Now" buttons
- Auto-fills event details (title, date, time, location)
- Registration form with validation
- Success confirmation on submission

### 4.4 Contact Form Validation
- Client-side validation for required fields
- Email format validation
- Visual feedback (red borders) for invalid fields
- Privacy consent checkbox required
- Success message displayed on valid submission

### 4.5 FAQ Accordion
- Bootstrap accordion component
- Expandable/collapsible FAQ items
- One item open at a time
- Smooth transitions

### 4.6 Back to Top Button
- Floating button appears when scrolling down 300px
- Smooth scroll animation back to top
- Hover effects and transitions

### 4.7 Book Details Loader
- Reads book ID from URL query parameter
- Dynamically loads book information into the page
- Falls back to default book if no ID specified

### 4.8 Book Card Interactions
- Clickable book cards navigate to details page
- Hover effects with lift animation and shadow enhancement
- Availability badges (green for Available, yellow for On Loan)

---

## 5. Design Features

### Color Scheme
- **Primary:** Deep blue (#1a4d6e) — represents trust, knowledge, and calm
- **Secondary:** Warm gold (#c9a961) — represents warmth, quality, and value
- **Accent:** Warm orange (#d4723a) — for highlights and calls-to-action
- **Background:** Warm cream (#f8f5f0) — inviting, paper-like feel

### Typography
- **Headings:** Comfortaa — rounded, friendly, modern sans-serif
- **Body:** Source Sans 3 — highly readable, clean, professional

### Responsive Breakpoints
- **Mobile:** < 576px (1 column layout)
- **Tablet:** 576px – 992px (2 column layout)
- **Desktop:** > 992px (3-4 column layout)

---

## 6. Browser Compatibility

Tested and compatible with:
- Google Chrome (latest 2 versions)
- Mozilla Firefox (latest 2 versions)
- Safari (latest 2 versions)
- Microsoft Edge (latest 2 versions)

---

## 7. How to Run

1. Download the entire `website` folder
2. Open `index.html` in any modern web browser
3. Navigate through the site using the header menu

**No build process or server required** — this is a static website that runs directly in the browser.

---

## 8. User Guide

### For Library Visitors:
- **Browse Books:** Click "Books" in the navigation → Use search bar to find books → Filter by category or availability → Click any book card for details
- **Find Events:** Click "Events" in the navigation → Browse all events → Click "Register Now" to sign up for any event
- **Contact Library:** Click "Contact" → Fill in the enquiry form → Check the FAQ section for quick answers
- **View Sitemap:** Click "Sitemap" for a complete overview of all pages

---

## 9. Accessibility Features

- Semantic HTML5 elements for screen readers
- Proper color contrast ratios (minimum 4.5:1)
- Keyboard navigable forms and interactive elements
- ARIA labels on icon-only buttons
- Responsive font sizes
- Clear visual hierarchy and focus states

---

## 10. Testing Checklist

| Test Item | Status |
|---|---|
| All 7 HTML pages load correctly | ✅ Pass |
| Navigation links work between all pages | ✅ Pass |
| Book search filters results in real-time | ✅ Pass |
| Category filter works correctly | ✅ Pass |
| Availability filter works correctly | ✅ Pass |
| Event modal opens with correct details | ✅ Pass |
| Contact form validates required fields | ✅ Pass |
| FAQ accordion expands/collapses | ✅ Pass |
| Back to top button appears on scroll | ✅ Pass |
| Mobile responsive layout works | ✅ Pass |
| Bootstrap components function properly | ✅ Pass |
| All external CDN resources load | ✅ Pass |
