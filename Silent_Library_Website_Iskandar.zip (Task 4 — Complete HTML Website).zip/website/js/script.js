/* ============================================
   Silent Library Website - JavaScript
   ============================================ */

// --- Book Data ---
const booksData = [
    {
        id: 1,
        title: "The Midnight Library",
        author: "Matt Haig",
        category: "Fiction",
        available: true,
        cover: "linear-gradient(135deg, #1a4d6e, #2a6d9c)",
        description: "Between life and death there is a library, and within that library, the shelves go on forever. Every book provides a chance to try another life you could have lived.",
        publisher: "Canongate Books",
        year: 2020,
        pages: 304,
        isbn: "978-1786892737"
    },
    {
        id: 2,
        title: "Atomic Habits",
        author: "James Clear",
        category: "Self-Help",
        available: true,
        cover: "linear-gradient(135deg, #c9a961, #d4723a)",
        description: "An easy and proven way to build good habits and break bad ones. Transform your life one tiny change at a time.",
        publisher: "Avery",
        year: 2018,
        pages: 320,
        isbn: "978-0735211292"
    },
    {
        id: 3,
        title: "Educated",
        author: "Tara Westover",
        category: "Biography",
        available: false,
        cover: "linear-gradient(135deg, #6b4423, #8b5a2b)",
        description: "A memoir about a young girl who, kept out of school, leaves her survivalist family and goes on to earn a PhD from Cambridge University.",
        publisher: "Random House",
        year: 2018,
        pages: 352,
        isbn: "978-0399590504"
    },
    {
        id: 4,
        title: "Project Hail Mary",
        author: "Andy Weir",
        category: "Science Fiction",
        available: true,
        cover: "linear-gradient(135deg, #2c3e50, #34495e)",
        description: "A lone astronaut must save the earth from disaster in this incredible new science-based thriller from the author of The Martian.",
        publisher: "Ballantine Books",
        year: 2021,
        pages: 496,
        isbn: "978-0593135204"
    },
    {
        id: 5,
        title: "The Silent Patient",
        author: "Alex Michaelides",
        category: "Mystery",
        available: true,
        cover: "linear-gradient(135deg, #4a1942, #6b2d5c)",
        description: "A woman shoots her husband and then never speaks another word. A criminal psychotherapist becomes obsessed with her case.",
        publisher: "Celadon Books",
        year: 2019,
        pages: 336,
        isbn: "978-1250301697"
    },
    {
        id: 6,
        title: "Sapiens",
        author: "Yuval Noah Harari",
        category: "Non-Fiction",
        available: false,
        cover: "linear-gradient(135deg, #8b4513, #a0522d)",
        description: "A brief history of humankind. From the Stone Age to the Silicon Age, explore how we came to dominate the world.",
        publisher: "Harper",
        year: 2015,
        pages: 464,
        isbn: "978-0062316097"
    },
    {
        id: 7,
        title: "Where the Crawdads Sing",
        author: "Delia Owens",
        category: "Fiction",
        available: true,
        cover: "linear-gradient(135deg, #2d5016, #4a7c23)",
        description: "A murder mystery and coming-of-age story set in the marshlands of North Carolina.",
        publisher: "G.P. Putnam's Sons",
        year: 2018,
        pages: 384,
        isbn: "978-0735219090"
    },
    {
        id: 8,
        title: "The Psychology of Money",
        author: "Morgan Housel",
        category: "Finance",
        available: true,
        cover: "linear-gradient(135deg, #1a4d6e, #c9a961)",
        description: "Timeless lessons on wealth, greed, and happiness doing well with money isn't about what you know.",
        publisher: "Harriman House",
        year: 2020,
        pages: 256,
        isbn: "978-0857197689"
    },
    {
        id: 9,
        title: "Dune",
        author: "Frank Herbert",
        category: "Science Fiction",
        available: true,
        cover: "linear-gradient(135deg, #d4723a, #c9a961)",
        description: "Set on the desert planet Arrakis, Dune is the story of the boy Paul Atreides, heir to a noble family tasked with ruling an inhospitable world.",
        publisher: "Ace",
        year: 1965,
        pages: 688,
        isbn: "978-0441172719"
    },
    {
        id: 10,
        title: "Becoming",
        author: "Michelle Obama",
        category: "Biography",
        available: false,
        cover: "linear-gradient(135deg, #1a1a2e, #2d2d44)",
        description: "An intimate, powerful, and inspiring memoir by the former First Lady of the United States.",
        publisher: "Crown",
        year: 2018,
        pages: 448,
        isbn: "978-1524763138"
    },
    {
        id: 11,
        title: "The Alchemist",
        author: "Paulo Coelho",
        category: "Fiction",
        available: true,
        cover: "linear-gradient(135deg, #c9a961, #e0c98a)",
        description: "A mystical story about following your dreams and listening to your heart. A modern classic.",
        publisher: "HarperOne",
        year: 1988,
        pages: 208,
        isbn: "978-0062315007"
    },
    {
        id: 12,
        title: "Thinking, Fast and Slow",
        author: "Daniel Kahneman",
        category: "Non-Fiction",
        available: true,
        cover: "linear-gradient(135deg, #2c3e50, #1a4d6e)",
        description: "A groundbreaking tour of the mind and explains the two systems that drive the way we think.",
        publisher: "Farrar, Straus and Giroux",
        year: 2011,
        pages: 512,
        isbn: "978-0374533559"
    }
];

// --- Events Data ---
const eventsData = [
    {
        id: 1,
        title: "Storytelling for Kids",
        date: "15",
        month: "SEP",
        time: "10:00 AM - 11:30 AM",
        location: "Children's Section",
        category: "Children",
        description: "Join us for a magical morning of stories, songs, and fun activities for children aged 4-8."
    },
    {
        id: 2,
        title: "Creative Writing Workshop",
        date: "22",
        month: "SEP",
        time: "2:00 PM - 5:00 PM",
        location: "Meeting Room A",
        category: "Workshop",
        description: "Learn the art of storytelling and creative writing from published authors in this hands-on workshop."
    },
    {
        id: 3,
        title: "Senior Book Club",
        date: "28",
        month: "SEP",
        time: "9:30 AM - 11:00 AM",
        location: "Lounge Area",
        category: "Seniors",
        description: "A monthly book club for our senior members. This month we discuss 'The Midnight Library' by Matt Haig."
    },
    {
        id: 4,
        title: "Tech Basics for Beginners",
        date: "05",
        month: "OCT",
        time: "3:00 PM - 5:00 PM",
        location: "Computer Lab",
        category: "Workshop",
        description: "New to computers? Learn essential skills including email, internet browsing, and online safety."
    },
    {
        id: 5,
        title: "Author Meet & Greet",
        date: "12",
        month: "OCT",
        time: "6:30 PM - 8:30 PM",
        location: "Main Hall",
        category: "Special",
        description: "Meet bestselling author Sarah Mitchell as she discusses her latest novel and answers audience questions."
    },
    {
        id: 6,
        title: "Study Skills Masterclass",
        date: "19",
        month: "OCT",
        time: "1:00 PM - 4:00 PM",
        location: "Meeting Room B",
        category: "Students",
        description: "Perfect for students! Learn effective study techniques, note-taking strategies, and exam preparation tips."
    }
];

// --- DOM Ready ---
document.addEventListener('DOMContentLoaded', function() {
    initBackToTop();
    initBookFilters();
    renderFeaturedBooks();
    renderAllBooks();
    renderEvents();
    initContactForm();
    initEventModals();
});

// --- Back to Top Button ---
function initBackToTop() {
    const backToTop = document.getElementById('backToTop');
    if (!backToTop) return;

    window.addEventListener('scroll', function() {
        if (window.scrollY > 300) {
            backToTop.classList.add('visible');
        } else {
            backToTop.classList.remove('visible');
        }
    });

    backToTop.addEventListener('click', function() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
}

// --- Book Search & Filter ---
function initBookFilters() {
    const searchInput = document.getElementById('searchInput');
    const categoryFilter = document.getElementById('categoryFilter');
    const availabilityFilter = document.getElementById('availabilityFilter');

    if (!searchInput && !categoryFilter && !availabilityFilter) return;

    const filterBooks = () => {
        const searchTerm = searchInput ? searchInput.value.toLowerCase() : '';
        const category = categoryFilter ? categoryFilter.value : 'all';
        const availability = availabilityFilter ? availabilityFilter.value : 'all';

        const filtered = booksData.filter(book => {
            const matchesSearch = book.title.toLowerCase().includes(searchTerm) ||
                                  book.author.toLowerCase().includes(searchTerm);
            const matchesCategory = category === 'all' || book.category === category;
            const matchesAvailability = availability === 'all' ||
                (availability === 'available' && book.available) ||
                (availability === 'loan' && !book.available);
            return matchesSearch && matchesCategory && matchesAvailability;
        });

        displayFilteredBooks(filtered);
    };

    if (searchInput) searchInput.addEventListener('input', filterBooks);
    if (categoryFilter) categoryFilter.addEventListener('change', filterBooks);
    if (availabilityFilter) availabilityFilter.addEventListener('change', filterBooks);
}

function displayFilteredBooks(books) {
    const container = document.getElementById('booksGrid');
    const resultsCount = document.getElementById('resultsCount');
    if (!container) return;

    if (resultsCount) {
        resultsCount.textContent = `Showing ${books.length} of ${booksData.length} books`;
    }

    if (books.length === 0) {
        container.innerHTML = `
            <div class="col-12 no-results">
                <i class="bi bi-book-x"></i>
                <h5>No books found</h5>
                <p>Try adjusting your search or filter criteria</p>
            </div>
        `;
        return;
    }

    container.innerHTML = books.map(book => createBookCardHTML(book)).join('');
}

function createBookCardHTML(book) {
    const badgeClass = book.available ? 'badge-available' : 'badge-loan';
    const badgeText = book.available ? 'Available' : 'On Loan';

    return `
        <div class="col-md-6 col-lg-3 mb-4">
            <div class="book-card" onclick="viewBookDetails(${book.id})">
                <div class="book-cover" style="background: ${book.cover}">
                    <span class="book-badge ${badgeClass}">${badgeText}</span>
                    <div class="book-cover-placeholder">
                        <i class="bi bi-book"></i>
                        <div style="font-size: 0.9rem; margin-top: 10px;">${book.title}</div>
                    </div>
                </div>
                <div class="book-info">
                    <h5>${book.title}</h5>
                    <p class="book-author">by ${book.author}</p>
                    <span class="book-category">${book.category}</span>
                </div>
            </div>
        </div>
    `;
}

function viewBookDetails(bookId) {
    window.location.href = `book-details.html?id=${bookId}`;
}

// --- Render Featured Books (Homepage) ---
function renderFeaturedBooks() {
    const container = document.getElementById('featuredBooks');
    if (!container) return;

    const featured = booksData.slice(0, 4);
    container.innerHTML = featured.map(book => createBookCardHTML(book)).join('');
}

// --- Render All Books (Books Page) ---
function renderAllBooks() {
    const container = document.getElementById('booksGrid');
    if (!container) return;

    container.innerHTML = booksData.map(book => createBookCardHTML(book)).join('');
}

// --- Render Events ---
function renderEvents() {
    const container = document.getElementById('eventsGrid');
    const upcomingContainer = document.getElementById('upcomingEvents');

    if (container) {
        container.innerHTML = eventsData.map(event => createEventCardHTML(event)).join('');
    }

    if (upcomingContainer) {
        const upcoming = eventsData.slice(0, 3);
        upcomingContainer.innerHTML = upcoming.map(event => createEventCardHTML(event)).join('');
    }
}

function createEventCardHTML(event) {
    return `
        <div class="col-md-6 col-lg-4 mb-4">
            <div class="event-card h-100">
                <div class="event-image">
                    <div class="event-date-badge">
                        <span class="day">${event.date}</span>
                        <span class="month">${event.month}</span>
                    </div>
                    <i class="bi bi-calendar-event"></i>
                </div>
                <div class="event-content d-flex flex-column h-100">
                    <span class="book-category mb-2" style="align-self: flex-start;">${event.category}</span>
                    <h5>${event.title}</h5>
                    <div class="event-meta">
                        <div><i class="bi bi-clock"></i> ${event.time}</div>
                        <div><i class="bi bi-geo-alt"></i> ${event.location}</div>
                    </div>
                    <p style="color: var(--text-muted); font-size: 0.9rem; flex-grow: 1;">${event.description}</p>
                    <button class="btn btn-primary btn-sm mt-auto" style="align-self: flex-start;" 
                            onclick="openEventModal(${event.id})">Register Now</button>
                </div>
            </div>
        </div>
    `;
}

// --- Event Registration Modal ---
function initEventModals() {
    // Modal is handled by Bootstrap data attributes
    // Additional JS for form submission can go here
}

function openEventModal(eventId) {
    const event = eventsData.find(e => e.id === eventId);
    if (!event) return;

    document.getElementById('modalEventTitle').textContent = event.title;
    document.getElementById('modalEventDate').textContent = `${event.date} ${event.month} 2026`;
    document.getElementById('modalEventTime').textContent = event.time;
    document.getElementById('modalEventLocation').textContent = event.location;
    document.getElementById('registerEventId').value = eventId;

    const modal = new bootstrap.Modal(document.getElementById('eventModal'));
    modal.show();
}

// --- Contact Form Validation ---
function initContactForm() {
    const form = document.getElementById('contactForm');
    if (!form) return;

    form.addEventListener('submit', function(e) {
        e.preventDefault();

        let isValid = true;
        const name = document.getElementById('contactName');
        const email = document.getElementById('contactEmail');
        const subject = document.getElementById('contactSubject');
        const message = document.getElementById('contactMessage');
        const consent = document.getElementById('contactConsent');

        // Reset error states
        [name, email, subject, message].forEach(field => {
            field.classList.remove('is-invalid');
        });

        // Validate
        if (!name.value.trim()) {
            name.classList.add('is-invalid');
            isValid = false;
        }

        if (!email.value.trim() || !isValidEmail(email.value)) {
            email.classList.add('is-invalid');
            isValid = false;
        }

        if (!subject.value.trim()) {
            subject.classList.add('is-invalid');
            isValid = false;
        }

        if (!message.value.trim()) {
            message.classList.add('is-invalid');
            isValid = false;
        }

        if (!consent.checked) {
            alert('Please agree to the privacy policy to submit the form.');
            isValid = false;
        }

        if (isValid) {
            // Show success message
            const successMsg = document.createElement('div');
            successMsg.className = 'alert alert-success mt-3';
            successMsg.innerHTML = '<i class="bi bi-check-circle"></i> Thank you! Your message has been sent successfully. We will get back to you within 2-3 business days.';
            form.appendChild(successMsg);
            form.reset();

            setTimeout(() => {
                successMsg.remove();
            }, 5000);
        }
    });

    // Event registration form
    const regForm = document.getElementById('registrationForm');
    if (regForm) {
        regForm.addEventListener('submit', function(e) {
            e.preventDefault();

            const name = document.getElementById('regName').value.trim();
            const email = document.getElementById('regEmail').value.trim();
            const phone = document.getElementById('regPhone').value.trim();

            if (!name || !email) {
                alert('Please fill in all required fields.');
                return;
            }

            if (!isValidEmail(email)) {
                alert('Please enter a valid email address.');
                return;
            }

            // Success
            const modal = bootstrap.Modal.getInstance(document.getElementById('eventModal'));
            modal.hide();

            setTimeout(() => {
                alert(`Thank you, ${name}! You have successfully registered for the event. A confirmation email has been sent to ${email}.`);
            }, 300);

            regForm.reset();
        });
    }
}

function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// --- Load Book Details ---
function loadBookDetails() {
    const params = new URLSearchParams(window.location.search);
    const bookId = parseInt(params.get('id')) || 1;
    const book = booksData.find(b => b.id === bookId) || booksData[0];

    if (!book) return;

    const coverEl = document.getElementById('bookDetailCover');
    if (coverEl) {
        coverEl.style.background = book.cover;
        coverEl.innerHTML = `
            <i class="bi bi-book"></i>
            <h4 style="margin-top: 20px;">${book.title}</h4>
        `;
    }

    document.getElementById('bookDetailTitle').textContent = book.title;
    document.getElementById('bookDetailAuthor').textContent = `by ${book.author}`;
    document.getElementById('bookDetailDescription').textContent = book.description;

    const statusEl = document.getElementById('bookAvailabilityStatus');
    if (statusEl) {
        statusEl.className = `availability-status ${book.available ? 'status-available' : 'status-loan'}`;
        statusEl.innerHTML = `<i class="bi ${book.available ? 'bi-check-circle' : 'bi-clock'} me-2"></i>${book.available ? 'Available' : 'On Loan'}`;
    }

    document.getElementById('bookPublisher').textContent = book.publisher;
    document.getElementById('bookYear').textContent = book.year;
    document.getElementById('bookPages').textContent = book.pages;
    document.getElementById('bookCategory').textContent = book.category;
    document.getElementById('bookISBN').textContent = book.isbn;
}

// Call loadBookDetails when on book-details page
if (window.location.pathname.includes('book-details.html')) {
    document.addEventListener('DOMContentLoaded', loadBookDetails);
}
